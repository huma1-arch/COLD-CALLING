
import React, { useState, useEffect } from 'react';
import { Lead, LeadStatus } from './types';
import { LeadSearch } from './components/LeadSearch';
import { LeadTable } from './components/LeadTable';
import { Analytics } from './components/Analytics';
import { generateOutreachEmail } from './services/geminiService';

const App: React.FC = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [activeEmail, setActiveEmail] = useState<{ lead: Lead; content: string } | null>(null);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [lastSearchSummary, setLastSearchSummary] = useState('');
  const [sources, setSources] = useState<any[]>([]);

  // Local storage persistence
  useEffect(() => {
    const saved = localStorage.getItem('logi_leads');
    if (saved) setLeads(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('logi_leads', JSON.stringify(leads));
  }, [leads]);

  const handleLeadsFound = (newLeads: Lead[], summary: string, foundSources: any[]) => {
    setLeads(prev => [...newLeads, ...prev]);
    setLastSearchSummary(summary);
    setSources(foundSources);
  };

  const handleStatusChange = (id: string, status: LeadStatus) => {
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
  };

  const handleGenerateEmail = async (lead: Lead) => {
    try {
      const content = await generateOutreachEmail(lead);
      setActiveEmail({ lead, content });
      setIsEmailModalOpen(true);
    } catch (err) {
      alert("Failed to generate email draft.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 pb-12">
      {/* Header */}
      <nav className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center font-bold text-white text-xl">L</div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
              LogiLeads AI
            </h1>
          </div>
          <div className="flex gap-4">
            <button className="text-slate-400 hover:text-white transition-colors px-3 py-1">Support</button>
            <button className="bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-semibold border border-slate-700">Export CSV</button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 pt-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Dispatcher Intel Dashboard</h2>
          <p className="text-slate-400">Manage and discover trucking dispatch leads across global logistics hubs.</p>
        </div>

        {/* Analytics Section */}
        <Analytics leads={leads} />

        {/* Discovery Tool */}
        <div className="mb-10">
          <LeadSearch onLeadsFound={handleLeadsFound} />
          {lastSearchSummary && (
            <div className="mt-4 p-4 bg-blue-900/20 border border-blue-800/50 rounded-lg text-blue-200 text-sm">
              <strong>AI Analysis:</strong> {lastSearchSummary}
            </div>
          )}
        </div>

        {/* Grounding Sources (if available) */}
        {sources.length > 0 && (
          <div className="mb-6">
            <h4 className="text-xs font-semibold text-slate-500 uppercase mb-3">Grounding Sources (Search Results)</h4>
            <div className="flex flex-wrap gap-2">
              {sources.map((s, idx) => (
                <a 
                  key={idx} 
                  href={s.web?.uri || '#'} 
                  target="_blank" 
                  rel="noreferrer"
                  className="px-3 py-1 bg-slate-800 border border-slate-700 rounded-full text-xs text-blue-400 hover:bg-slate-700 transition-colors"
                >
                  {s.web?.title || 'Source'} 🔗
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Table View */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold text-white">Contact Registry</h3>
            <span className="bg-slate-800 px-3 py-1 rounded-full text-sm text-slate-300 border border-slate-700">
              {leads.length} Total Records
            </span>
          </div>
          <LeadTable 
            leads={leads} 
            onStatusChange={handleStatusChange} 
            onGenerateEmail={handleGenerateEmail} 
          />
        </div>
      </main>

      {/* Email Generator Modal */}
      {isEmailModalOpen && activeEmail && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-[100] backdrop-blur-sm">
          <div className="bg-slate-800 w-full max-w-2xl rounded-2xl border border-slate-700 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-700 flex justify-between items-center bg-slate-900">
              <h3 className="text-lg font-bold">Draft Outreach: {activeEmail.lead.companyName}</h3>
              <button 
                onClick={() => setIsEmailModalOpen(false)}
                className="text-slate-400 hover:text-white text-xl"
              >&times;</button>
            </div>
            <div className="p-6">
              <div className="mb-4">
                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Recipient</label>
                <div className="bg-slate-900 p-2 rounded text-slate-300 border border-slate-800">
                  {activeEmail.lead.contactName} ({activeEmail.lead.email})
                </div>
              </div>
              <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Email Content</label>
              <textarea 
                className="w-full h-80 bg-slate-900 border border-slate-700 rounded-lg p-4 text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none"
                value={activeEmail.content}
                readOnly
              />
              <div className="mt-6 flex justify-end gap-3">
                <button 
                  onClick={() => setIsEmailModalOpen(false)}
                  className="px-4 py-2 text-slate-400 font-medium"
                >Cancel</button>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(activeEmail.content);
                    alert("Email copied to clipboard!");
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold transition-all"
                >Copy Draft</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="text-center py-8 text-slate-600 text-sm border-t border-slate-900 mt-12">
        &copy; 2024 LogiLeads AI. High-fidelity dispatcher intelligence for the modern supply chain.
      </footer>
    </div>
  );
};

export default App;
