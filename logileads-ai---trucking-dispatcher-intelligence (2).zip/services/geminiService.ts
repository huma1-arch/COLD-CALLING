
import { GoogleGenAI, Type } from "@google/genai";
import { Lead, LeadStatus } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function searchLeads(region: 'US' | 'UK', query: string): Promise<{ leads: Lead[], sources: any[], summary: string }> {
  const prompt = `Deeply research active trucking dispatcher companies in the ${region} based on this query: "${query}". 
  For each company found, strictly extract the following specific details:
  1. Company Name and full location.
  2. A specific contact person (e.g., a manager or owner).
  3. Their exact Role (e.g., "Operations Manager", "Owner", "Lead Dispatcher").
  4. Direct contact information: professional email and direct phone number or extension.
  5. Company website and the contact's professional LinkedIn profile URL if available.
  
  Ensure the data is high-quality and verified via search.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "A brief summary of the search findings." },
          leads: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                companyName: { type: Type.STRING },
                location: { type: Type.STRING },
                website: { type: Type.STRING },
                email: { type: Type.STRING },
                phone: { type: Type.STRING },
                contactName: { type: Type.STRING },
                role: { type: Type.STRING },
                linkedIn: { type: Type.STRING }
              },
              required: ["companyName", "location"]
            }
          }
        }
      }
    }
  });

  const rawText = response.text;
  let data;
  try {
    data = JSON.parse(rawText);
  } catch (e) {
    console.error("Failed to parse AI response as JSON", rawText);
    throw new Error("Invalid response format from lead discovery engine.");
  }

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

  const processedLeads: Lead[] = (data.leads || []).map((l: any, index: number) => ({
    id: `lead-${Date.now()}-${index}`,
    companyName: l.companyName,
    location: l.location,
    contactName: l.contactName || 'Primary Contact',
    role: l.role || 'Dispatcher / Admin',
    email: l.email || 'Not Found',
    phone: l.phone || 'Not Found',
    website: l.website || '',
    linkedIn: l.linkedIn || '',
    status: LeadStatus.NEW,
    category: 'Dispatcher',
    region: region,
    source: 'AI Intelligence'
  }));

  return {
    leads: processedLeads,
    sources,
    summary: data.summary || `Found ${processedLeads.length} potential leads.`
  };
}

export async function generateOutreachEmail(lead: Lead): Promise<string> {
  const prompt = `Generate a highly personalized professional cold outreach email to ${lead.contactName}, the ${lead.role} at ${lead.companyName}. 
  The goal is to pitch high-efficiency trucking dispatch software that reduces overhead by 25%. 
  The tone should be professional, respectful of their time, and industry-savvy. 
  Location Context: ${lead.location}. 
  Include a clear call to action.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      temperature: 0.8,
      topP: 0.95
    }
  });

  return response.text;
}
