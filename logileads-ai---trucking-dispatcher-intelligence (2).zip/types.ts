
export interface Lead {
  id: string;
  companyName: string;
  location: string;
  contactName?: string;
  role?: string;
  email?: string;
  phone?: string;
  website?: string;
  linkedIn?: string;
  source?: string;
  status: LeadStatus;
  category: 'Dispatcher' | 'Broker' | 'Carrier';
  region: 'US' | 'UK';
}

export enum LeadStatus {
  NEW = 'New',
  CONTACTED = 'Contacted',
  QUALIFIED = 'Qualified',
  REJECTED = 'Rejected'
}

export interface SearchResult {
  leads: Lead[];
  sources: { title: string; uri: string }[];
  summary: string;
}

export interface AnalyticsData {
  name: string;
  count: number;
}
