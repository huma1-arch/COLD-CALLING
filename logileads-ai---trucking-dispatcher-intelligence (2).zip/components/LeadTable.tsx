
import React from 'react';
import { Lead, LeadStatus } from '../types';

interface LeadTableProps {
  leads: Lead[];
  onStatusChange: (id: string, status: LeadStatus) => void;
  onGenerateEmail: (lead: Lead) => void;
}

export const LeadTable: React.FC<LeadTableProps> = ({ leads, onStatusChange, onGenerateEmail }) => {
  return (
    <div className="overflow-x-auto bg-slate-800 rounded-xl shadow-lg border border-slate-700">
      <table className="w-full text-left">
        <thead className="bg-slate-900 text-slate-400 uppercase text-xs font-semibold">
          <tr>
            <th className="px-6 py-4">Company & Location</th>
            <th className="px-6 py-4">Contact & Role</th>
            <th className="px-6 py-4">Contact Info</th>
            <th className="px-6 py-4">Links</th>
            <th className="px-6 py-4">Status</th>
            <th className="px-6 py-4 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-700">
          {leads.map((lead) => (
            <tr key={lead.id} className="hover:bg-slate-700/50 transition-colors">
              <td className="px-6 py-4 font-medium text-white">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${lead.region === 'US' ? 'bg-blue-500' : 'bg-red-500'}`}></span>
                  {lead.companyName}
                </div>
                <div className="text-xs text-slate-500 mt-1">{lead.location}</div>
              </td>
              <td className="px-6 py-4">
                <div className="text-slate-200 font-medium">{lead.contactName}</div>
                <div className="text-xs text-blue-400 italic">{lead.role}</div>
              </td>
              <td className="px-6 py-4 text-sm text-slate-300">
                <div className="flex flex-col gap-1">
                  <span className="flex items-center gap-1">
                    <span className="opacity-50 text-[10px]">📧</span> {lead.email}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-slate-400">
                    <span className="opacity-50 text-[10px]">📞</span> {lead.phone}
                  </span>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="flex gap-3">
                  {lead.website && (
                    <a href={lead.website.startsWith('http') ? lead.website : `https://${lead.website}`} target="_blank" rel="noreferrer" title="Website" className="text-slate-400 hover:text-white transition-colors">
                      🌐
                    </a>
                  )}
                  {lead.linkedIn && (
                    <a href={lead.linkedIn} target="_blank" rel="noreferrer" title="LinkedIn" className="text-slate-400 hover:text-blue-400 transition-colors">
                      in
                    </a>
                  )}
                </div>
              </td>
              <td className="px-6 py-4">
                <select
                  value={lead.status}
                  onChange={(e) => onStatusChange(lead.id, e.target.value as LeadStatus)}
                  className={`bg-slate-900 border border-slate-700 rounded text-xs p-1 focus:ring-1 focus:ring-blue-500 outline-none ${
                    lead.status === LeadStatus.QUALIFIED ? 'text-emerald-400' : 
                    lead.status === LeadStatus.REJECTED ? 'text-rose-400' : 'text-slate-200'
                  }`}
                >
                  {Object.values(LeadStatus).map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </td>
              <td className="px-6 py-4 text-right">
                <button
                  onClick={() => onGenerateEmail(lead)}
                  className="bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white px-3 py-1 rounded text-xs font-semibold transition-all border border-blue-600/20"
                >
                  Draft AI Email
                </button>
              </td>
            </tr>
          ))}
          {leads.length === 0 && (
            <tr>
              <td colSpan={6} className="px-6 py-20 text-center text-slate-500 italic">
                <div className="flex flex-col items-center gap-2">
                  <span className="text-4xl opacity-20">📡</span>
                  No leads found yet. Use the search tool to scan for dispatchers.
                </div>
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
