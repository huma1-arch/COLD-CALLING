
import React, { useState } from 'react';
import { searchLeads } from '../services/geminiService';
import { Lead } from '../types';

interface LeadSearchProps {
  onLeadsFound: (leads: Lead[], summary: string, sources: any[]) => void;
}

export const LeadSearch: React.FC<LeadSearchProps> = ({ onLeadsFound }) => {
  const [region, setRegion] = useState<'US' | 'UK'>('US');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query) return;
    setLoading(true);
    try {
      const result = await searchLeads(region, query);
      onLeadsFound(result.leads, result.summary, result.sources);
    } catch (error) {
      console.error("Search failed:", error);
      alert("An error occurred while searching for leads.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-700">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
        <span className="p-2 bg-blue-600 rounded-lg">🔍</span>
        Lead Discovery Engine
      </h2>
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <input
            type="text"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="e.g. Independent trucking dispatchers in Texas or London logistics hubs..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <select
            className="bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={region}
            onChange={(e) => setRegion(e.target.value as 'US' | 'UK')}
          >
            <option value="US">🇺🇸 USA</option>
            <option value="UK">🇬🇧 UK</option>
          </select>
          <button
            onClick={handleSearch}
            disabled={loading}
            className={`px-6 py-2 rounded-lg font-semibold transition-all ${
              loading ? 'bg-slate-600 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {loading ? 'Discovering...' : 'Find Leads'}
          </button>
        </div>
      </div>
      <p className="mt-4 text-slate-400 text-sm italic">
        * Our AI uses real-time Google Search grounding to locate high-intent dispatch contacts.
      </p>
    </div>
  );
};
